import React, { useEffect, useState } from "react";
import axios from "axios";
import { FaChartLine, FaUser, FaMoneyBill, FaPills, FaCog } from "react-icons/fa";
import "../styles/Admin.css";
import "../styles/User.css";
import "../styles/UserPrescription.css";

const UserPrescriptions = () => {
  const [prescriptions, setPrescriptions] = useState([]);

  useEffect(() => {
    fetchAllPrescriptions();
  }, []);

  const fetchAllPrescriptions = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/prescriptions/all");
      setPrescriptions(response.data);
    } catch (error) {
      console.error("Error fetching prescriptions:", error);
    }
  };

  return (
    <div className="admin-container">
      {/* Sidebar */}
      <aside className="admin-sidebar">
        <div className="sidebar-header">
          <h2>Pharmacy</h2>
        </div>
        <ul className="sidebar-menu">
          <li>
            <a href="/admin">
              <FaChartLine /> Dashboard
            </a>
          </li>
          <li>
            <a href="/product-management">
              <FaMoneyBill /> Product Management
            </a>
          </li>
          <li className="prescription">
            <a href="/userprescription">
              <FaPills /> Prescription Management
            </a>
          </li>
          <li>
            <a href="/user">
              <FaUser /> User Management
            </a>
          </li>
          <li>
            <a className="customer" href="/feedbacklist">
              <FaPills /> Customer Feedback Reports
            </a>
          </li>
          <li>
            <a href="#settings">
              <FaCog /> Settings
            </a>
          </li>
        </ul>
      </aside>

      {/* Main Content */}
      <main className="admin-main">
        <div className="user-list-container">
          <h2>All User Prescriptions</h2>
          {prescriptions.length === 0 ? (
            <p>No prescriptions uploaded.</p>
          ) : (
            <div className="prescription-list">
              {prescriptions.map((pres) => (
                <div key={pres.id} className="prescription-card">
                  <p><strong>Name:</strong> {pres.name}</p>
                  <p><strong>Email:</strong> {pres.email}</p>
                  <p><strong>Phone:</strong> {pres.phone}</p>
                  <p>
                    <strong>File:</strong>{" "}
                    <a
                      href={`http://localhost:8080/${pres.filePath}`}
                      target="_blank"
                      rel="noreferrer"
                    >
                      View
                    </a>
                  </p>
                  <p>
                    <strong>Approved:</strong>{" "}
                    <span style={{ color: pres.approved ? "green" : "red" }}>
                      {pres.approved ? "Yes" : "No"}
                    </span>
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default UserPrescriptions;
