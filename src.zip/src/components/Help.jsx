import React, { useState, useEffect } from "react";

const Help = () => {
  const [content, setContent] = useState("");
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchMessages();
  }, []);

  const fetchMessages = async () => {
    setLoading(true);
    const userId = localStorage.getItem("userId"); // Get userId from localStorage or JWT
    if (!userId) {
      console.error("User not found.");
      setLoading(false);
      return;
    }
    
    try {
      const res = await fetch(`http://localhost:8080/api/help/messages/${userId}`);
      const data = await res.json();
      console.log("Fetched messages:", data);

      if (Array.isArray(data)) {
        setMessages(data);
      } else {
        console.error("Fetched data is not an array:", data);
        setMessages([]); // Fallback to empty array
      }
    } catch (error) {
      console.error("Failed to fetch messages", error);
      setMessages([]); // Fallback to empty array on error
    } finally {
      setLoading(false);
    }
  };

  const handleSendMessage = async () => {
    if (!content) {
      alert("Please type a message.");
      return;
    }

    const userId = localStorage.getItem("userId"); // Or extract from JWT
    if (!userId) {
      alert("User not found.");
      return;
    }

    setLoading(true);
    try {
      await fetch("http://localhost:8080/api/help/message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content, sender: "user", chat: { user: { id: userId } } }),
      });

      setContent("");
      await fetchMessages(); // Refresh after sending
    } catch (error) {
      console.error("Failed to send message", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Help and Support</h2>

      <div style={{ marginBottom: "20px" }}>
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Type your message here"
          rows="4"
          style={{ width: "100%", padding: "10px" }}
        />
        <button onClick={handleSendMessage} disabled={loading} style={{ marginTop: "10px" }}>
          {loading ? "Sending..." : "Send Message"}
        </button>
      </div>

      <div style={{ marginTop: "20px" }}>
        <h4>Messages:</h4>
        {loading ? (
          <p>Loading messages...</p>
        ) : messages.length === 0 ? (
          <p>No messages yet. Start the conversation!</p>
        ) : (
          <div id="chat-container" style={{ maxHeight: "300px", overflowY: "auto" }}>
            {messages.map((msg) => (
              <div key={msg.id}>
                <p>
                  <strong>{msg.sender === "staff" ? "Staff" : "User"}:</strong> {msg.content}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Help;
